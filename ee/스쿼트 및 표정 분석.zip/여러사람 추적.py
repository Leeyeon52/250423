import cv2
import mediapipe as mp
import time
import numpy as np

mp_drawing = mp.solutions.drawing_utils
mp_pose = mp.solutions.pose

# 웹캠 설정
cap = cv2.VideoCapture(0)
pTime = 0

with mp_pose.Pose(
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5,
    model_complexity=1,
    static_image_mode=False,
    enable_segmentation=False,
    min_pose_detection_confidence=0.5,
    min_tracking_confidence=0.5,
    max_num_poses=2) as pose:  # 최대 2명까지 추적

    while cap.isOpened():
        success, image = cap.read()
        if not success:
            print("Ignoring empty camera frame.")
            continue

        image.flags.writeable = False
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        results = pose.process(image)
        image.flags.writeable = True
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        h, w, _ = image.shape

        if results.multi_pose_landmarks:
            for i, pose_landmarks in enumerate(results.multi_pose_landmarks):
                # 각 사람마다 다른 색깔로 랜드마크 그리기
                color = (0, 255 * (i + 1) % 256, 255 * i % 256)  # 간단한 색상 생성
                mp_drawing.draw_landmarks(
                    image,
                    pose_landmarks,
                    mp_pose.POSE_CONNECTIONS,
                    landmark_drawing_spec=mp_drawing_styles.get_default_pose_landmarks_style(),
                    connection_drawing_spec=mp_drawing_styles.get_default_pose_connections_style(),
                    )

                # 두 사람이 감지되었을 경우 손목 사이 거리 측정
                if len(results.multi_pose_landmarks) == 2:
                    person1_landmarks = results.multi_pose_landmarks[0].landmark
                    person2_landmarks = results.multi_pose_landmarks[1].landmark

                    # 오른쪽 손목 좌표 추출
                    right_wrist1 = np.array([person1_landmarks[mp_pose.PoseLandmark.RIGHT_WRIST].x * w,
                                             person1_landmarks[mp_pose.PoseLandmark.RIGHT_WRIST].y * h])
                    right_wrist2 = np.array([person2_landmarks[mp_pose.PoseLandmark.RIGHT_WRIST].x * w,
                                             person2_landmarks[mp_pose.PoseLandmark.RIGHT_WRIST].y * h])

                    # 거리 계산
                    distance_right_wrists = np.linalg.norm(right_wrist1 - right_wrist2)
                    cv2.putText(image, f'Dist(R): {int(distance_right_wrists)}',
                                (10, 100), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

                    # 왼쪽 손목 좌표 추출
                    left_wrist1 = np.array([person1_landmarks[mp_pose.PoseLandmark.LEFT_WRIST].x * w,
                                            person1_landmarks[mp_pose.PoseLandmark.LEFT_WRIST].y * h])
                    left_wrist2 = np.array([person2_landmarks[mp_pose.PoseLandmark.LEFT_WRIST].x * w,
                                            person2_landmarks[mp_pose.PoseLandmark.LEFT_WRIST].y * h])

                    # 거리 계산
                    distance_left_wrists = np.linalg.norm(left_wrist1 - left_wrist2)
                    cv2.putText(image, f'Dist(L): {int(distance_left_wrists)}',
                                (10, 150), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

        cTime = time.time()
        fps = 1 / (cTime - pTime)
        pTime = cTime
        cv2.putText(image, f'FPS: {int(fps)}', (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)

        cv2.imshow('Multi Person Pose Tracking', cv2.flip(image, 1))

        if cv2.waitKey(5) & 0xFF == 27:
            break

cap.release()
cv2.destroyAllWindows()